from django.shortcuts import render
import mysql.connector
from django.contrib import messages

posts = [
    {
        'author': 'CoreyMS',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date_posted': 'August 27, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date_posted': 'August 28, 2018'
    }
]


def login(request):
    #val1 = request.GET["name"]
    return render(request, 'webDevelopement/login.html')

def new(request):
    return render(request, 'webDevelopement/new.html')


def home(request):
    nmmm=request.GET['nm1']
    psw1=request.GET['psw']
    #DataBAse Validation
    mb=db()
    mycursor=mb.cursor()
    sel=f"select * from login where user='{nmmm}' and password='{psw1}'"
    print(sel)
    mycursor.execute(sel)
    li=mycursor.fetchall()
    print(li)
    print(len(li))
    if len(li) == 0:
        print("Invalid Credential")
        messages.warning(request, f'Invalid Credential!')
        return render(request, 'webDevelopement/login.html')
    else:
        nm="Jyoti"
        return render(request, 'webDevelopement/home.html', {'result':nmmm})

def add(request):
    return render(request, 'users/register.html')

def insert(request):
    nmmm=request.GET['user']
    psw1=request.GET['pswDetails']
    mb=db()
    mycursor=mb.cursor()
    sel=f"select * from login where user='{nmmm}' and password='{psw1}'"

    print(sel)
    mycursor.execute(sel)
    li=mycursor.fetchall()
    print(li)
    print(len(li))
    if len(li) == 1:
        print("User Allready exist")
        messages.warning(request, f'User Allready exist!')
        return render(request, 'users/register.html')
    else:
        insert="insert into login(user,password) values(%s,%s)"
        emp=[(f"{nmmm}",f"{psw1}"),]
        mycursor.executemany(insert,emp)
        mb.commit()
        return render(request, 'users/SuccessfullRegistration.html')

def db():
    mb=mysql.connector.connect(host="localhost", user="root", passwd="root", database="chatbot")
    if (mb):
        print("Connection successfully jyotiiiii")
    else:
        print("UnSuccessfull") 
    mycursor=mb.cursor()
    mycursor.execute("Show tables")
    flag= False
    for db in mycursor:
        print(db)
        if db != ('login',):
            print("Invalid Login")
        else:
            print("valid")
    return mb
