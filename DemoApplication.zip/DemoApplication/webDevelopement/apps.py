from django.apps import AppConfig


class WebdevelopementConfig(AppConfig):
    name = 'webDevelopement'
