from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
#from .forms import UserRegisterForm


def register(request):
    return render(request, 'users/register.html')




